﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

namespace GestionAlmacen
{
    public class Servidor
    {
        //static void Main(string[] args) { 
            
        //    Pale pale = new Pale("007", 20, "yes", date);
        //    Ubicacion ubicacion = new Ubicacion("5", "izq", "4", "3");

        //}
    }
}